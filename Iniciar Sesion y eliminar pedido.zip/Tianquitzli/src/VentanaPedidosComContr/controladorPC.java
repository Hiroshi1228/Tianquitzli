package VentanaPedidosComContr;

import VentanaPedidosComModelo.pedidosCom;
import VentanaPedidosComModelo.pedidosComDAO;
import VentanaPedidosComVista.VentanPedidosCom;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class controladorPC implements ActionListener{
    
    pedidosComDAO daopc = new pedidosComDAO();
    pedidosCom comp = new pedidosCom();
    VentanPedidosCom vpc = new VentanPedidosCom();
    DefaultTableModel model = new DefaultTableModel();
    
    public controladorPC(VentanPedidosCom pedcv){
        this.vpc=pedcv;
        this.vpc.btnDelete.addActionListener(this);
        listarPed(vpc.tablaDatos);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vpc.btnDelete){
            delete();
            limpiarTabla();
            listarPed(vpc.tablaDatos);
        }
    }
    
    public void listarPed(JTable tablaDatos){
        model=(DefaultTableModel)tablaDatos.getModel();
        List<pedidosCom>lista=daopc.listar();
        Object[]object=new Object[5];
        for(int i=0;i<lista.size();i++){
            object[0]=lista.get(i).getId_Pe();
            object[1]=lista.get(i).getId_C();
            object[2]=lista.get(i).getEstado();
            object[3]=lista.get(i).getDireccion();
            object[4]=lista.get(i).getProductos();
            model.addRow(object);
        }
        vpc.tablaDatos.setModel(model);
    }

    public void delete(){
         int fila=vpc.tablaDatos.getSelectedRow();
         int pid=Integer.parseInt((String)vpc.tablaDatos.getValueAt(fila,0).toString());
         if(fila==-1){
             JOptionPane.showMessageDialog(vpc,"Debe seleccionar un pedidoa antes.");
         }else{
             daopc.delete(pid);
             JOptionPane.showMessageDialog(vpc,"Pedido cancelado.");
         }
    }
    
    void limpiarTabla(){
        for(int i=0;i<vpc.tablaDatos.getRowCount();i++){
            model.removeRow(i);
            i=i-1;
        }
    }
}
