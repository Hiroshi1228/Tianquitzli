package tianquiztli;

public class Tianquiztli {
    public static void main(String[] args) {
        VentanaLogin log = new VentanaLogin();
        log.setVisible(true);
    }
}