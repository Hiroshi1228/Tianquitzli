package VentanaPedidosComModelo;

public class pedidosCom {
    int id_Pe;
    int id_C;
    String estado;
    String direccion;
    String productos;

    public pedidosCom() {
    }

    public pedidosCom(int id_Pe, int id_C, String estado, String direccion, String productos) {
        this.id_Pe = id_Pe;
        this.id_C = id_C;
        this.estado = estado;
        this.direccion = direccion;
        this.productos = productos;
    }

    public int getId_Pe() {
        return id_Pe;
    }

    public int getId_C() {
        return id_C;
    }

    public String getEstado() {
        return estado;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getProductos() {
        return productos;
    }

    public void setId_Pe(int id_Pe) {
        this.id_Pe = id_Pe;
    }

    public void setId_C(int id_C) {
        this.id_C = id_C;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setProductos(String productos) {
        this.productos = productos;
    }
}
