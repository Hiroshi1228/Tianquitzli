package VentanaPedidosComModelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class pedidosComDAO {
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public List listar(){
        List<pedidosCom>datos=new ArrayList<>();
        String sql="select * from pedidos";
        try{
            con=conectar.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {
                pedidosCom pedc=new pedidosCom();
                pedc.setId_Pe(rs.getInt(1));
                pedc.setId_C(rs.getInt(2));
                pedc.setEstado(rs.getString(3));
                pedc.setDireccion(rs.getString(4));
                pedc.setProductos(rs.getString(5));
                datos.add(pedc);
            }
        }catch (SQLException e){
        }
        return datos;
    }
    
    public void delete(int idpe){
        String sql="delete from pedidos where id_Pe="+idpe;
        try{
            con=conectar.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }catch (SQLException e){
        }
    }
}
