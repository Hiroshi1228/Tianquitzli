/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Aridai
 */
import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionBD{

    Connection connection = null;

    public String driver = "com.mysql.jdbc.Driver";

    // Nombre de la base de datos
    public String database = "tianquiztli";

    // Host
    public String hostname = "localhost";

    // Puerto
    public String port = "3306";

    // Ruta de nuestra base de datos (desactivamos el uso de SSL con "?useSSL=false")
   // public String url = "jdbc:mariadb://localhost:3306/ejemplo_crud?user=root&password=";
    public String url = "jdbc:mysql://" + hostname + ":" + port + "/" + database + "?useSSL=false";

    // Nombre de usuario
    public String username = "root";

    // Clave de usuario
    public String password = "";
    
    public ConexionBD(){
        this.hostname = "localhost";
        this.port = "3306";
        this.database = "tianquiztli";
        this.username = "root";
        this.password = "";

        this.driver = "com.mysql.jdbc.Driver";
        this.url = "jdbc:mysql://" + hostname + ":" + port + "/" + database + "?useSSL=false";
    }

    public Connection getConnection() throws Exception{
        try {
            Class.forName(driver);
            System.out.println("Haciendo conexion");
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException ex) {
            throw new Exception("Error en ConexionDB. La causa es: Fallo al conectar con la base de datos, inténtelo más tarde");
        }
    }

    public void desconectar(){
        try{
            System.out.println("Cerrando conexion");
            connection.close();
        }catch(Exception ex){}
    }


}

